# Todo

0. Should run the latest angular version
1. Change app name
2. Guarded routes > Left button (Router should activate)
3. Tables > Fixed table should display
4. Tables > Feature table should filter and sort
5. Pages > Contact; Should be able to add new contact
6. Should be able to clear notifications
7. Should generate notification when task is assigned to developers and testers in scrumboard
8. Material widgets should work
