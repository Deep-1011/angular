export interface Employees {
  userName: string;
  post: string;
}
