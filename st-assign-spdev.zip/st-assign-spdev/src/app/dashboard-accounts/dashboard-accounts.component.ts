import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-accounts',
  templateUrl: './dashboard-accounts.component.html',
  styleUrls: ['./dashboard-accounts.component.scss']
})
export class DashboardAccountsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
